require("dotenv").config("./.env");
const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');
 
const apiRouter = require('./services/apiRouter');
 
const app = express();
const PORT = process.env.PORT

app.use(bodyParser.json());
app.use(morgan('combined'));

app.use(apiRouter)
 
app.listen(PORT, ()=>{
    console.log(`server is listening  on ${PORT}`);
});
 
module.exports = app;